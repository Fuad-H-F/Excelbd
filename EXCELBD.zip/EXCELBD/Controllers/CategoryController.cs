﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using EXCELBD.Models;

namespace EXCELBD.Controllers
{
    public class CategoryController : Controller { 

        private excel db = new excel();
    
        // GET: Category
        public ActionResult Index()
        {
            var tbl_category = db.tbl_category.Include(t => t.tbl_expense);
            return View(tbl_category.ToList());
        }



        // GET: tbl_Profile/Create
        public ActionResult Create()
        {

            var CATlist = db.tbl_category.ToList();
            ViewBag.CATlist = new SelectList(CATlist, "id", "categoryTittle");
            return View();
        }

        // POST: tbl_Profile/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "id,categoryTittle")] tbl_category tbl_category)
        {
            if (ModelState.IsValid)
            {
                db.tbl_category.Add(tbl_category);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.id = new SelectList(db.tbl_expense, "id", "categoryTittle", tbl_category.id);
            return View(tbl_category);
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_category tbl_category = db.tbl_category.Find(id);
            if (tbl_category == null)
            {
                return HttpNotFound();
            }
            return View(tbl_category);
        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_category tbl_category = db.tbl_category.Find(id);
            if (tbl_category == null)
            {
                return HttpNotFound();
            }
            // ViewBag.RankId = new SelectList(db.tbl_category, "RankId", "RankName", tbl_Profile.RankId);
            return View(tbl_category);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,categoryTittle")] tbl_category tbl_category)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tbl_category).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            //ViewBag.RankId = new SelectList(db.tbl_Performance, "RankId", "RankName", tbl_Profile.RankId);
            return View(tbl_category);
        }

        // GET: tbl_Profile/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_category tbl_Profile = db.tbl_category.Find(id);
            if (tbl_Profile == null)
            {
                return HttpNotFound();
            }
            return View(tbl_Profile);
        }

        // POST: tbl_Profile/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            tbl_category tbl_Profile = db.tbl_category.Find(id);
            db.tbl_category.Remove(tbl_Profile);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
