﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using EXCELBD.Models;

namespace EXCELBD.Controllers
{
    public class ExpenseController : Controller
    {
        private excel db = new excel();
        // GET: Expense
        public ActionResult Index()
        {
            var tbl_expense = db.tbl_expense.Include(t => t.tbl_category);
            return View(tbl_expense.ToList());
        }



        // GET: Expense/Create
        public ActionResult Create()
        {

            //var CATlist = db.tbl_category.ToList();
            //ViewBag.CATlist = new SelectList(CATlist, "id", "categoryTittle");
            return View();
        }

        // POST: tbl_Profile/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "id,category_id,date,expense")] tbl_expense tbl_expense)
        {
            if (ModelState.IsValid)
            {
                db.tbl_expense.Add(tbl_expense);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            //ViewBag.id = new SelectList(db.tbl_expense, "id", "categoryTittle", tbl_category.id);
            return View(tbl_expense);
        }


        // GET: tbl_Profile/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_expense tbl_Profile = db.tbl_expense.Find(id);
            if (tbl_Profile == null)
            {
                return HttpNotFound();
            }

            return View(tbl_Profile);
        }

        // POST: tbl_Profile/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,category_id,date,expense")] tbl_expense tbl_expense)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tbl_expense).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(tbl_expense);
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_expense tbl_expense = db.tbl_expense.Find(id);
            if (tbl_expense == null)
            {
                return HttpNotFound();
            }
            return View(tbl_expense);
        }



        // GET: tbl_Profile/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            tbl_expense tbl_expense = db.tbl_expense.Find(id);
            if (tbl_expense == null)
            {
                return HttpNotFound();
            }
            return View(tbl_expense);
        }

        // POST: tbl_Profile/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            tbl_expense tbl_expense = db.tbl_expense.Find(id);
            db.tbl_expense.Remove(tbl_expense);
            db.SaveChanges();
            return RedirectToAction("Index");
        }


    }
}
